from DataHandler import get_data, get_EUT_data
import FileHandler as fh
import pandas as pd
import os
import csv
import sys
import constants
import codecs
import math
import datetime
from tqdm import tqdm
import logging
import linecache
import traceback
"""
-------------------- Overview of Program --------------------------------
extract_data.py:
    This is the main file that starts the program and calls the other modules. This file takes the pandas dataframe
    that contains only frequency and magnitude data from the .Result file and adds additional columns to it, such as
    the "Test Time", "Package", etc. This file also separates the masks in the .Result file and calculates the data
    for each mask. The limit line calculations are also done in this file and added to the dataframe. The program returns
    a master_dataframe that is turned into a .csv file that contains all of the columns and values.
FileHandler.py:
    This file handles searching for files in the user-inputted directory. The .Result files are found by this module. This
    file also handles the data extraction mode user-input option.
DataHandler.py:
    This file handles getting the Frequency and Magnitude data from the .Result file and adding it to a dataframe, which is
    then passed to extract_data.py for additional columns and data to be added. This file also contains the functions for
    getting the EUT data from the EUT file, which is called in the extract_data.py file. This file also checks if the data in
    the .Result file is Emissions or DPI data.
constants.py:
    This file contains variables that are used in all of the files. Most of the variables are constants, but some are changed
    by functions in the program, such as certain lists.
ErrorsLog.log:
    This file will contain tracebacks of any errors that cause the program to crash. A message in the command prompt will be
    displayed notifying the user to check the ErrorsLog.log file if the program crashes. Other errors that are already handlded
    by the program and don't cause it to crash will simply be displayed on the command prompt without any action needing to be
    taken by the user. Additionally, if the program crashes and there is no error in the ErrorsLog.log file, the program can be
    run in a manually opened command prompt, which will not close automatically.
-------------------------------------------------------------------------
"""
def main():
    #logging.basicConfig(filename='RuntimeErrorsLog.log', format='%(asctime)s: %(message)s: ', filemode='w', level=logging.DEBUG)
    error_logger = logging.getLogger(__name__)
    handler = logging.FileHandler('ErrorsLog.log', mode='w')
    formatter = logging.Formatter('[%(asctime)s] %(levelname)8s ' + '(%(filename)s: %(lineno)s)', datefmt='%Y-%m-%d %H:%M:%S')
    handler.setFormatter(formatter)
    error_logger.addHandler(handler)
    try:
        info_type = get_user_input_info()   # User input info type
        dir_path = get_user_input_dir() # User input directory path of root folder containing data files
        overwrite = get_user_input_overwrite()  # User input for overwriting .csv files

        file_path_list = []
        df_list = []
        master_df = pd.DataFrame()

        correct_mode = False
        while not correct_mode: # Get user input for mode
            mode = get_user_input_mode()
            if mode.lower() == constants.MODE_SELECTIVE or mode.lower() == 's':    # Mode is selective
                file_path_list = fh.get_dir(dir_path, overwrite)
                correct_mode = True
            elif mode.lower() == constants.MODE_GENERAL or mode.lower() == 'g':    # Mode is general
                file_path_list = fh.get_file(dir_path, info_type, overwrite)
                correct_mode = True
            else:
                print("Invalid mode type.")

        if file_path_list:  # List of paths of folders containing all data (.Result, EUT, TestSetup)
            try:
                for path in tqdm(file_path_list, desc="Creating individual .CSV Files", total = len(file_path_list), file=sys.stdout):
                    os.chdir(path)
                    df = get_data(constants.FILE_NAME, info_type)
                    EUT_dict = {}
                    if info_type.lower() == constants.TYPE_DPI:
                        EUT_dict = get_EUT_data(constants.EUT_FILE_NAME)
                    if df.empty:
                        continue
                    mask_df_list = create_mask_df(df, EUT_dict)   # Create list of mask dataframes
                    
                    num_masks = len(mask_df_list)   # Subtract 1 because list contains all masks + the original data (i.e. 2 masks in file = 2 masks + 1 = 3 data frames total)
                    
                    for i in range(num_masks):

                        mask_df_list[i] = add_identifier_columns(mask_df_list[i], info_type, path, num_masks, i).copy(deep=True)    # Add additional columns (including MT columns)
            
                        new_filename = create_new_filename(path, constants.CSV_FILE_NAME, 0, '', None, num_masks, i)    # Create .csv filename for individual .Result files
                        try:
                            mask_df_list[i].to_csv(new_filename, sep = ',', index = False)
                        except IOError as e:
                            tqdm.write(str(e))
                            tqdm.write("Filename too long. Creating generic filename instead.\n")
                            generic_new_filename = create_generic_filename(constants.CSV_FILE_NAME, 0, '', None, num_masks, i)
                            mask_df_list[i].to_csv(generic_new_filename, sep = ',', index = False)

                        if 'MT1' in mask_df_list[i].columns:    # If dataframe has MT column -> drop them
                            for j in range(num_masks - 1):                     
                                mask_df_list[i].drop('MT{}'.format(j + 1), axis=1, inplace=True)
                    
                        mask_df_list[i]['Limit Line'] = ''  # Add limit line column and set values to empty
                        
                        df_list.append((mask_df_list[i], path.split('\\')[-1])) # Append individual dataframes to list
                        
                if not df_list: # If list of dataframes is empty
                    print(("\nNo \".Result\" files found for data of type [{}].".format(info_type.upper())))
                    return None
                master_df = create_master_df(df_list)   # Combine all dataframes into a master dataframe
                
                ll_step_size = get_user_input_ll_increment()
                master_df = add_limit_line(master_df, df_list, dir_path, info_type, ll_step_size).copy(deep=True) # Add limit line values to limit line dataframe in master dataframe

                os.chdir(dir_path)
                try:
                    if master_df.shape[0] > constants.EXCEL_MAX_ROWS:   # If dataframe has more rows than possible in excel file -> split the dataframe up into multiple excel file parts
                        df_chunk_list = split_dataframe(master_df, constants.EXCEL_MAX_ROWS - 1)    # Subtract 1 b/c header line is included in excel file
                        for i in tqdm(list(range(len(df_chunk_list))), desc = "Splitting up aggregated .CSV files", total = len(df_chunk_list)):
                            aggregated_chunk_csv_filename = create_new_filename(dir_path, constants.AGGREGATED_CSV_FILE_NAME, i + 1, info_type, constants.KEYS)
                            df_chunk_list[i].to_csv(aggregated_chunk_csv_filename, sep = ',', index = False)
                    else:
                        aggregated_csv_filename = create_new_filename(dir_path, constants.AGGREGATED_CSV_FILE_NAME, 0, info_type, constants.KEYS) 
                        master_df.to_csv(aggregated_csv_filename, sep = ',', index = False)  # Create .csv file from master dataframe
                except IOError as e:
                    tqdm.write(str(e))
                    tqdm.write("Filename for aggregated file too long. Creating generic filename instead.\n")
                    
                    if master_df.shape[0] > constants.EXCEL_MAX_ROWS:
                        df_chunk_list = split_dataframe(master_df, constants.EXCEL_MAX_ROWS - 1)    # Subtract 1 b/c header line is included in excel file
                        for i in tqdm(list(range(len(df_chunk_list))), desc = "Splitting up aggregated .CSV files", total = len(df_chunk_list), ascii="*#"):
                            agg_generic_chunk_new_filename = create_generic_filename(constants.AGGREGATED_CSV_FILE_NAME, i + 1, info_type, constants.KEYS)
                            df_chunk_list[i].to_csv(aggregated_chunk_csv_filename, sep = ',', index = False)
                    else:
                        aggregated_generic_new_filename = create_generic_filename(constants.AGGREGATED_CSV_FILE_NAME, 0, info_type, constants.KEYS)
                        master_df.to_csv(aggregated_generic_new_filename, sep = ',', index=False)
                
                if mode.lower() == constants.MODE_SELECTIVE:    # Mode is selective
                    print("\".csv\" files for all selected \".Result\" files successfullly created.")
                else:    # Mode is general
                    print("\".csv\" files for all \".Result\" files successfullly created.")
                
            except OSError:
                print("Can't create Pandas dataframe.")
                print(("Error: " + sys.exc_info()[0]))
        input("Press any key to exit...")
    except:        
        #tqdm.write(traceback.format_exc()) # Don't need to print error to console (just put in log file)
        error_logger.exception(traceback.format_exc())
        input("An error occurred. Check \"ErrorsLog.log\" file for error.\nPress any key to exit...")


def get_user_input_info():
    """
    Asks user for input for type of data.\n

    :return: type of info as string.
    """
    info_type = input("Select information type ({}): ".format(', '.join(constants.INFO_TYPES_LIST)))

    while info_type not in constants.INFO_TYPES_LIST:
        print("The selected information type is not an available option.")
        info_type = input("Select information type ({}): ".format(', '.join(constants.INFO_TYPES_LIST)))
    return info_type


def get_user_input_dir():
    """
    Asks user for input for directory path of folder containing all data.\n

    :return: directory path as string.
    """
    dir_path = input("Enter directory path: ")
    return dir_path


def get_user_input_mode():
    """
    Asks user for input for mode of extracting data\n

    :return: mode type
    """
    mode = input("Select data extraction mode ({}) (G/S): ".format(', '.join(constants.MODE_TYPES_LIST)))
    while mode not in constants.MODE_TYPES_LIST and mode.lower() != 'g' and mode.lower() != 's':
        print("The selected mode type is not an available option.")
        mode  = input("Select data extraction mode ({}) (G/S): ".format(', '.join(constants.MODE_TYPES_LIST)))
    return mode


def get_user_input_overwrite():
    """
    Asks user if they want to overwrite current .csv files or skip them when creating and aggregating data.\n

    :return: boolean
    """
    overwrite_flag = False
    overwrite = False
    while not overwrite_flag:
        input_overwrite = input("Overwrite current \".csv\" files (Y/N)? ")
        if input_overwrite.lower() == "y" or input_overwrite.lower() == "yes":
             overwrite = True
             overwrite_flag = True
        elif input_overwrite.lower() == "n" or input_overwrite.lower() == "no":
            overwrite = False
            overwrite_flag = True

    return overwrite


def get_user_input_ll_increment():
    """
    Asks user for incrementation step size of limit line frequencies

    :return: increment size
    """
    is_number = False
    while not is_number:
        try:
            step_size = float(input("Enter limit line frequency incrementation size: "))
            is_number = True
        except ValueError as e:
            print("Step size must be a number.")
    return float(step_size)


def create_new_filename(path, appended_filename, chunk_position=0, info_type='', keys=None, num_masks=1, mask_index=0):
    """
    Creates new file name for generated .csv file.\n

    :param path: path to directory of .Result file.\n
    :param appended_filename: name to append to folder name in the file name.\n
    :param keys: keys in custom search to add to file name.\n
    :return: name of generated .csv file as string.
    """
    file_base_name = path.split('\\')[-1]
    mask_name = ''
    if num_masks > 1 and mask_index != num_masks - 1:
        mask_name = '_M{}'.format(mask_index + 1)
    if keys:
        keys_as_string = ' '.join(map(str, keys))
        string_keys = "_keys=[{}]".format(keys_as_string if keys else "")
        if chunk_position != 0:
            if not info_type:
                return file_base_name + string_keys + mask_name + '_Part_{}'.format(chunk_position) + appended_filename # Name for individual .csv files
            else:
                return file_base_name + string_keys + mask_name + '_{}'.format(info_type).upper() + '_Part_{}'.format(chunk_position) + appended_filename   # Name for aggregated .csv files
        else:
            if not info_type:
                return file_base_name + string_keys + mask_name + appended_filename # Name for individual .csv files
            else:
                return file_base_name + string_keys + mask_name + '_{}'.format(info_type).upper() + appended_filename   # Name for aggregated .csv files
    else:
        if chunk_position != 0: # If master df needs to be split up into multiple .csv files
            if not info_type:
                return file_base_name + mask_name + '_Part_{}'.format(chunk_position) + appended_filename   # Name for individual .csv files
            else:
                return file_base_name + mask_name + '_{}'.format(info_type).upper() + '_Part_{}'.format(chunk_position) + appended_filename # Name for aggregates .csv files
        else:   # If master df does not need to be split up into multiple .csv files
            if not info_type:
                return file_base_name + mask_name + appended_filename   # Name for individual .csv files
            else:
                return file_base_name + mask_name + '_{}'.format(info_type).upper() + appended_filename # Name for aggregates .csv files


def create_master_df(df_list):
    """
    Creates a master dataframe that combines all of the data files and limit lines files in 1 dataframe.\n

    :param df_list: list of dataframes to combine into a master dataframe
    :return: dataframe containing all datafarmes in df_list
    """
    master_dict = {}
    master_df = pd.DataFrame()

    # Check length of dataframe (# of rows) to determine size for new dictionary (master_dict)
    # Arrays in master_dict need to be same size to put into pandas dataframe
    lf_index, largest_index_row = 0, len(df_list[0][0])
    for i in range(1, len(df_list)):
        index_row = len(df_list[i][0])
        if index_row > largest_index_row:
            lf_index, largest_index_row = i, index_row

    for df in df_list:
        master_df = master_df.append(df[0], ignore_index=True, sort=False).copy(deep=True)
    master_df['Frequency'] = pd.to_numeric(master_df['Frequency'], errors='coerce').copy(deep=True)

    return master_df


def add_identifier_columns(data_frame, info_type, path, num_masks, mask_index = 0):
    keys = path.split('\\')[-1].split(' ')
    folder_name = path.split('\\')[-1]
    if num_masks > 1 and mask_index != num_masks - 1:   # Skip original dataframe (last index in list) if there are masks
        data_frame['Data Set'] = folder_name + "_M{}".format(mask_index + 1)
    else:
        data_frame['Data Set'] = folder_name
    test_start_time = get_test_start_time(path) # Get string of test start time
    try:
        data_frame.insert(3, 'Test Time', test_start_time, False)
    except ValueError as e:
        tqdm.write("Error: Test Time column already added")

    # Add columns whose values will be taken from the folder name
    if info_type.lower() == constants.TYPE_EMISSION:    # Add identifier columns for emission data
        for i in range(len(constants.EMISSION_IDENTIFIERS)):
            if constants.EMISSION_IDENTIFIERS[i] == '-':    # If column header is '-' -> don't add as column
                continue
            data_frame[constants.EMISSION_IDENTIFIERS[i]] = keys[i] if i < len(keys) and keys[i] != '-' else ''
    elif info_type.lower() == constants.TYPE_DPI:   # Add identifier columns for dpi data
        for i in range(len(constants.DPI_IDENTIFIERS)):
            if constants.DPI_IDENTIFIERS[i] == '-': # If column header is '-' -> don't add as column
                continue
            data_frame[constants.DPI_IDENTIFIERS[i]] = keys[i] if i < len(keys) and keys[i] != '-' else ''

    return data_frame


def add_limit_line(master_df, df_list, path, info_type, ll_step_size):
    limit_line_file_flag = False
    limit_line_file_list = []
    temp_ll_file_list = []
    for (root, dirs, files) in os.walk(path, topdown=True): # Walk through all folders in root_dir
        for filename in files:
            if filename.endswith(constants.LIMIT_LINE_FILE_SUFFIX): # if .LimitLine file is in folder
                if filename == constants.IGNORE_LL_HEADER:  # Ignore TargetLevel.LimitLine file
                    continue
                limit_line_file_flag = True               
                if filename not in temp_ll_file_list:
                    limit_line_file_list.append(os.path.join(root, filename))
                    temp_ll_file_list.append(filename)
    if not limit_line_file_flag:    # If no limit line files found
        print(("No \".LimitLine\" files found in specified path ({}).".format(path)))

    df_only_list = []
    for df in df_list:  # Get just the dataframes and put them into a list (for easier access)
        df_only_list.append(df[0])

    for limit_line_path in tqdm(limit_line_file_list, desc = "Adding limit line data", total = len(limit_line_file_list), file=sys.stdout): # Create limit line df for each file in limit line list
        df = df_only_list[0].copy(deep=True)    # temp df for limit line df
        for col in df.columns:
            if col not in constants.IMPORTANT_COL_NAMES:    # Empty data in columns not necessary for limit line df
                df[col] = ''
        
        df['Data Set'] = 'LL ' + os.path.splitext(limit_line_path.split('\\')[-1])[0] # Create name for data set (LL + filename w/o extension)
        
        with codecs.open(limit_line_path, encoding='utf-16-le') as limit_line_file:
            LL_start_freq = 0
            LL_stop_freq = 0  
            for line in limit_line_file:  # Skips lines until reading 'TableValues' line
                if constants.LL_START_FREQ_LABEL.encode(encoding='utf-16-le') in line.encode(encoding='utf-16-le'):
                    LL_start_freq = float(line.replace('Start=', '')) * 1e-6    # Convert Hz to MHz
                if constants.LL_Stop_FREQ_LABEL.encode(encoding='utf-16-le') in line.encode(encoding='utf-16-le'):
                    LL_stop_freq = float(line.replace('Stop=', '')) * 1e-6  # Convert Hz to MHz
                if constants.DATA_HEADER.encode(encoding='utf-16-le') not in line.encode(encoding='utf-16-le'): # Check for 'TableValues' string in line 
                    continue
                else:
                    break
                
            limit_lines = limit_line_file.readlines() # Get all remaining lines in file

            if not limit_lines: # If .LimitLine file has no data to read -> skip the file
                tqdm.write("Failed to read Limit Line file [{}] because file is corrupted or no data is available.".format(limit_line_path.split('\\')[-1]))
                continue
            ll_frequency_list = create_ll_frequency([], LL_start_freq, LL_stop_freq, ll_step_size)   # Create frequency values for limit line
            curr_line = limit_lines[0]
            temp_df_list = []
            for i in range(1, len(limit_lines)):
                prev_line = curr_line
                curr_line = limit_lines[i]

                slope = get_limit_line_slope(prev_line, curr_line)
                coord0 = get_coord(prev_line)
                coord1 = get_coord(curr_line)

                if math.isnan(slope):
                    continue
                ll_df = pd.DataFrame()
                if float(limit_lines[-1].strip('\n').strip().split('\t')[1]) < ll_frequency_list[-1]:
                    temp_freq_list = list([x for x in ll_frequency_list if x <= float(limit_lines[-1].strip('\n').strip().split('\t')[1])])
                    ll_df = create_ll_df(df, temp_freq_list, limit_line_path)
                else:
                    ll_df = create_ll_df(df, ll_frequency_list, limit_line_path)
                ll_df = create_ll_df(df, ll_frequency_list, limit_line_path)
                
                ll_df.sort_values(by='Frequency', ascending=True)
                # Split full dataframe into smaller dataframes based on the frequency range that matches .LimitLine file frequencies
                temp_df = ll_df.loc[(ll_df.loc[:, 'Frequency'].apply(lambda x: float(x)) >= coord0[0]) & (ll_df.loc[:, 'Frequency'].apply(lambda x: float(x)) <= coord1[0]), :].copy(deep=True) # ------------ REMEMBER TO CONVERT NUMBERS IN DF FROM STRING TO FLOAT ------------------------------------
                # Calculate limit at certain frequency
                temp_df.loc[:, 'Limit Line'] = temp_df.loc[:, 'Frequency'].apply(lambda x: calc_limit(slope, float(x), coord0, coord1)).copy(deep=True)
                # Append sectioned limit line dataframe to temporary list
                temp_df_list.append(temp_df)
            
            # Combine all limit line dataframe sections into a single dataframe
            new_df = pd.concat(temp_df_list, ignore_index=True)
        
            # Append limit line dataframe to master dataframe
            master_df = master_df.append(new_df, ignore_index=True, sort=False).copy(deep=True)
       
    return master_df

def get_limit_line_slope(signal0, signal1):
    """
    Calculates slope of limit line based on 2 coordinates\n

    :param signal0: first signal to use for slope calculation\n
    :param signal1: second signal to use for slope calculation\n

    :return: slope of limit line
    """
    signal_list0 = signal0.strip('\n').strip().split('\t')
    signal_list1 = signal1.strip('\n').strip().split('\t')
    
    x0 = float(signal_list0[0])    # frequency
    y0 = float(signal_list0[1])    # limit line value

    x1 = float(signal_list1[0])   # frequency
    y1 = float(signal_list1[1])    # limit line value

    try:
        slope = (y1-y0)/(math.log10(x1/x0))
        return slope
    except ZeroDivisionError:
        return float('NaN')


def get_coord(signal):
    """
    Gets coordinates from limit line file\n
    :param signal: line from limit line file\n

    :return: tuple containing the x and y coordinates of the line read from limit line file\n
    """
    signal_list = signal.strip('\n').strip().split('\t')
    signal_list[0] = float(signal_list[0])
    signal_list[1] = float(signal_list[1])
    return tuple(signal_list)


def calc_limit(slope, frequency, coord0, coord1):
    """
    Calculates limit of limit line based on 2 coordinates\n

    :param slope: slope of limit line\n
    :param frequency: frequency to calculate limit value of\n
    :param coord0: first coordinate of limit line\n
    :param coord1: second coordinate of limit line\n
    """
    if slope == 0:
        return coord0[1]
    elif math.isnan(slope):
        return coord1[1]
    else:
        return slope * math.log10(frequency/coord0[0]) + coord0[1]


def create_ll_frequency(ll_frequency_list, start_freq, stop_freq, ll_step_size):
    """
    Creates list of individual frequencies for limit line\n

    :param ll_frequency_list: list to add frequencies to\n
    :param start_freq: starting frequency\n
    :param stop_freq: stopping frequency\n

    :return: list of frequencies for limit line
    """
    frequency = start_freq
    while frequency <= stop_freq:
        ll_frequency_list.append(frequency)
        frequency = frequency + ll_step_size    # Change increment to increase or decrease Limit Line accuracy
    """
    while frequency <= 6e3: # Max frequency is 1 GHz
        while frequency < 10:  # 0.15 - 10 MHz
            ll_frequency_list.append(frequency)
            frequency = frequency + 0.01   # Increment in 250 kHz steps
        while frequency >= 10 and frequency < 100:  # 10 - 100 MHz
            ll_frequency_list.append(frequency)
            frequency = frequency + .01   # Increment in 1 MHz steps
        while frequency >= 100 and frequency < 200: # 100 - 200 MHz
            ll_frequency_list.append(frequency)
            frequency = frequency + .01   # Increment in 2 MHz steps
        while frequency >= 200 and frequency < 400:  # 200 - 400 MHz
            ll_frequency_list.append(frequency)
            frequency = frequency + .01   # Increment in 4 MHz steps
        while frequency >= 400 and frequency < 1e3: # 400 MHz - 1 GHz
            ll_frequency_list.append(frequency)
            frequency = frequency + .01   # Increment in 10 MHz steps
        while frequency >= 1e3 and frequency <= 6e3:
            ll_frequency_list.append(frequency)
            frequency = frequency + .01
    """
    return ll_frequency_list


def create_ll_df(df, ll_list, path):
    """
    Creates limit line data frame with corresponding 'Data Set' value and frequency values\n

    :param df: dataframe to copy for columns\n
    :param ll_list: list of frequencies for limit line\n
    :param path: path of limit line file\n

    :return: dataframe for limit line
    """
    orig_num_rows = df.shape[0]
    new_num_rows = len(ll_list)
    temp_list = []
    col_names = list(df.columns)
    ll_df = pd.DataFrame(columns=col_names)
    ll_df['Frequency'] = ll_list
    ll_df['Data Set'] = 'LL ' + os.path.splitext(path.split('\\')[-1])[0] # Create name for data set (LL + filename w/o extension)
    return ll_df


def create_mask_df(df, EUT_dict):
    # 1) Turn DataFrame into dictionary
    # 2) Read Frequency, Power, and MT columns
    # 3) Create n dictionaries based on how many MT columns there are
    # 4) If all MT are 0 -> follow power levels
            # If both pass -> follow table
            # If 1 fails & 1 pass -> FAIL: assign value for it from EUT file / PASS: assign value for it from common_level (both pass)
            # If both fail -> assign both corresponding values from EUT file
    # 5) Turn all dictionaries into DataFrames
    # 6) Return list of DataFrames
    main_dict = df.to_dict()

    level_key = list(df.columns)[1] # Magnitude column header
    level_list = main_dict[level_key]   # Values in magnitude column
    df_list = []
    if 'MT3' in list(main_dict.keys()):   # If file has 3 masks
        common_level = level_list[0]
        m1_dict = df.copy(deep=True).to_dict()
        m2_dict = df.copy(deep=True).to_dict()
        m3_dict = df.copy(deep=True).to_dict()
        for i in range (len(main_dict['Frequency'])):
            if not main_dict['MT1'][i] or not main_dict['MT2'][i] or not main_dict['MT3'][i]: # Check if MT column has an empty value, and skip it if so
                continue
            m1 = float(main_dict['MT1'][i])
            m2 = float(main_dict['MT2'][i])
            m3 = float(main_dict['MT3'][i])
            try:
                if m1 == 0 and m2 == 0 and m3 == 0:
                    common_level = level_list[i]
                elif m1 == 1 and m2 == 0 and m3 == 0:
                    m2_dict[level_key][i] = common_level
                    m3_dict[level_key][i] = common_level
                    m1_dict[level_key][i] = EUT_dict[float(m1_dict['Frequency'][i])]['MT1']
                elif m2 == 1 and m1 == 0 and m3 == 0:
                    m1_dict[level_key][i] = common_level
                    m3_dict[level_key][i] = common_level
                    m2_dict[level_key][i] = EUT_dict[float(m2_dict['Frequency'][i])]['MT2']
                elif m3 == 1 and m1 == 0 and m2 == 0:
                    m2_dict[level_key][i] = common_level
                    m1_dict[level_key][i] = common_level
                    m3_dict[level_key][i] = EUT_dict[float(m3_dict['Frequency'][i])]['MT3']
                elif m1 == 1 and m2 == 1 and m3 == 0:
                    m1_dict[level_key][i] = EUT_dict[float(m1_dict['Frequency'][i])]['MT1']
                    m2_dict[level_key][i] = EUT_dict[float(m2_dict['Frequency'][i])]['MT2']
                    m3_dict[level_key][i] = common_level
                elif m1 == 1 and m3 == 1 and m2 == 0:
                    m1_dict[level_key][i] = EUT_dict[float(m1_dict['Frequency'][i])]['MT1']
                    m3_dict[level_key][i] = EUT_dict[float(m3_dict['Frequency'][i])]['MT3']
                    m2_dict[level_key][i] = common_level
                elif m2 == 1 and m3 == 1 and m1 == 0:
                    m2_dict[level_key][i] = EUT_dict[float(m2_dict['Frequency'][i])]['MT2']
                    m3_dict[level_key][i] = EUT_dict[float(m3_dict['Frequency'][i])]['MT3']
                    m1_dict[level_key][i] = common_level
                elif m1 == 1 and m2 == 1 and m3 == 1:
                    m1_dict[level_key][i] = EUT_dict[float(m1_dict['Frequency'][i])]['MT1']
                    m2_dict[level_key][i] = EUT_dict[float(m2_dict['Frequency'][i])]['MT2']
                    m3_dict[level_key][i] = EUT_dict[float(m3_dict['Frequency'][i])]['MT3']
            except KeyError as e:
                tqdm.write("Could not find frequency [{}] from \".Result file\" in EUT file.".format(e))
                tqdm.write("Using data from \".Result\" file instead.\n")
        m1_df = pd.DataFrame(m1_dict)
        m2_df = pd.DataFrame(m2_dict)
        m3_df = pd.DataFrame(m3_dict)
        df_list.append(m1_df)
        df_list.append(m2_df)
        df_list.append(m3_df)
    elif 'MT2' in list(main_dict.keys()): # If file has 2 masks
        common_level = level_list[0]
        m1_dict = df.copy(deep=True).to_dict()
        m2_dict = df.copy(deep=True).to_dict()
        
        for i in range (len(main_dict['Frequency'])):
            if not main_dict['MT1'][i] or not main_dict['MT2'][i]:  # Check if MT column has an empty value, and skip it if so
                continue
            try:
                m1 = float(main_dict['MT1'][i])
                m2 = float(main_dict['MT2'][i])
            except ValueError as e:
                tqdm.write("Mask convert to float error: " + str(e) + "on line " + str(i))
            
            try:
                if m1 == 0 and m2 == 0: # Change common level value & Make no change to data b/c both pass
                    common_level = level_list[i]
                elif m1 == 1 and m2 == 0:   # M1 fails -> Read EUT data / M2 pass -> Assign common level value
                    m2_dict[level_key][i] = common_level
                    m1_dict[level_key][i] = EUT_dict[float(m1_dict['Frequency'][i])]['MT1']  # Value of corresponding frequency in EUT_dict for MT1
                elif m2 == 1 and m1 == 0:   # M2 fails -> Read EUT data / M1 pass -> Assign common level value
                    m1_dict[level_key][i] = common_level
                    m2_dict[level_key][i] = EUT_dict[float(m2_dict['Frequency'][i])]['MT2']  # Value of corresponding frequency in EUT_dict for MT2
                elif m1 == 1 and m2 == 1:   # M1 & M2 fails -> Read EUT data
                    m1_dict[level_key][i] = EUT_dict[float(m1_dict['Frequency'][i])]['MT1']  # Value of corresponding frequency in EUT_dict for MT1
                    m2_dict[level_key][i] = EUT_dict[float(m2_dict['Frequency'][i])]['MT2']  # Value of corresponding frequency in EUT_dict for MT2
            except KeyError as e:
                tqdm.write("Could not find frequency [{}] from \".Result file\" in EUT file.".format(e))
                tqdm.write("Using data from \".Result\" file instead.\n")
        m1_df = pd.DataFrame(m1_dict)
        m2_df = pd.DataFrame(m2_dict)
        df_list.append(m1_df)
        df_list.append(m2_df)
    # Commented b/c always returning original dataframe
    #else:   # If file has no masks -> return the original dataframe
    df_list.append(df)  
    return df_list
    

def create_generic_filename(appended_filename, chunk_position=0, info_type='', keys=None, num_masks=1, mask_index=0):
    mask_name = ''
    string_keys = ''
    date = datetime.datetime.now().strftime("%Y_%m_%d-%I_%M_%S_%p")
    if num_masks > 1 and mask_index != num_masks - 1:
        mask_name = '_M{}'.format(mask_index + 1)
    if keys:
        keys_as_string = ' '.join(map(str, keys))
        string_keys = "_keys=[{}]".format(keys_as_string if keys else "")
    if chunk_position != 0:
        if not info_type:
            return 'Generic_Filename' + string_keys + mask_name + '_' + str(date) + '_Part_{}'.format(chunk_position) + appended_filename
        else:
            return 'Generic_Filename' + mask_name + '_{}'.format(info_type).upper() + str(date) + '_Part_{}'.format(chunk_position) + appended_filename # Name for aggregates .csv files
    else:
        if not info_type:
            return 'Generic_Filename' + string_keys + mask_name + '_' + str(date) +  appended_filename
        else:
            return 'Generic_Filename' + mask_name + '_{}'.format(info_type).upper() + str(date) + appended_filename # Name for aggregates .csv files


def split_dataframe(df, num_rows):
    """
    Split dataframe based on number of rows

    :param df: dataframe to split
    :param num_rows: number of rows each dataframe should have (except possibly last dataframe)
    """
    df_chunk_list = []
    temp_df = df.copy(deep=True)
    while temp_df.shape[0] > num_rows:
        df_chunk = temp_df.iloc[:num_rows, :].copy(deep=True)
        df_chunk_list.append(df_chunk)
        temp_df = temp_df.iloc[num_rows:, :].copy(deep=True)
    df_chunk_list.append(temp_df)

    return df_chunk_list


def get_test_start_time(path):
    testsetup_file = ''
    file_found = False
    for (root, dirs, files) in os.walk(path, topdown=True):
        for filename in files:
            if filename.endswith(constants.TESTSETUP_FILE_SUFFIX):
                testsetup_file = filename
                file_found = True
                break
        if file_found:
            break
    
    start_time = ''
    try:    # Try to open .TestSetup file and print error msg and skip if no file found
        with codecs.open(testsetup_file, encoding='utf-16-le') as data_file:
            for line in data_file:
                if constants.TESTSETUP_FILE_STARTTIME_HEADER in line:
                    start_time = line.strip('\n').strip().replace(constants.TESTSETUP_FILE_STARTTIME_HEADER, '')
                    break
        return start_time
    except IOError as e:
        tqdm.write('No \".TestSetup\" file found in folder [{}]\n'.format(path.split('\\')[-1]))


if __name__ == "__main__":
    main()