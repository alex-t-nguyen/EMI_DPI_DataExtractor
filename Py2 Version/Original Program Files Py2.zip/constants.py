# extract_data, FileHandler
FILE_NAME = 'Result Table.Result'
CSV_FILE_NAME = '_New_Results.csv'
EUT_FILE_NAME = 'Result Table_EutFailures.Result'
TESTSETUP_FILE_SUFFIX = '.TestSetup'
TESTSETUP_FILE_STARTTIME_HEADER = 'TestStart='
AGGREGATED_CSV_FILE_NAME = '_Aggregated_New_Results.csv'
MODE_GENERAL = 'general'
MODE_SELECTIVE = 'selective'
INFO_TYPES_LIST = ['emission', 'dpi']
MODE_TYPES_LIST = ['general', 'selective']
IMPORTANT_COL_NAMES = ['Frequency', 'Data Set', 'Limit Line']

# DataHandler
DATA_HEADER = 'TableValues'
TYPE_EMISSION = 'emission'
TYPE_DPI = 'dpi'
TYPE_EUT_FILE = 'EUT'
COLUMN_NAME_HEADER = 'Name='
EUT_COL_NAMES = ['Frequency', 'EUT Failure Mode', 'Thres. Imm. Level']

# Column Indices for info types
EMISSION_COL_INDEXES = [0, 1]   # 0: Frequency, 1: PK+_CLRWR
DPI_COL_INDEXES = [0, 1]    # 0: Frequency, 1: Imm Lvl-Pk
EUT_FILE_COL_INDEXES = [0, 1, 3]    # 0: Frequency, 1: EUT Failure Mode, 3: Thres, Imm. Level

# File naming
KEYS = []

# Identifier columns for info types
EMISSION_IDENTIFIERS = ['Part ID', 'PG', 'Trim', 'Choke']
DPI_IDENTIFIERS = ['Part ID', 'PG', 'Package', '-', '-', '-', 'Choke']

# Limit Line
IGNORE_LL_HEADER = 'TargetLevel.LimitLine'
LIMIT_LINE_FILE_SUFFIX = '.LimitLine'
LL_START_FREQ_LABEL = 'Start='
LL_Stop_FREQ_LABEL = 'Stop='

# Excel File
EXCEL_MAX_ROWS = 1048576